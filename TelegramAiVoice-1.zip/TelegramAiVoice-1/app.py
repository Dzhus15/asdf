import os
import logging
import time
from pathlib import Path
from flask import Flask, render_template, request, jsonify, send_file, session, url_for, Response
from services.tts_service import TTSService
import base64
import requests
from werkzeug.utils import secure_filename
from dataclasses import dataclass

@dataclass
class Voice:
    voice_id: str
    name: str
    language: str
    description: str

@dataclass
class VoiceMode:
    name: str
    stability: float
    similarity_boost: float
    style: float
    description: str

app = Flask(__name__)
app.config['STATIC_SOUNDS_DIR'] = Path('static/sounds')
app.config['AUDIO_FILE_RETENTION_DAYS'] = 1
app.config['DEFAULT_VOICE_ID'] = "21m00Tcm4TlvDq8ikWAM"
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "dev_secret_key")

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

tts_service = None
try:
    logger.info("Initializing TTS Service...")
    tts_service = TTSService()
    logger.info("TTS Service initialized successfully")
except Exception as e:
    logger.error(f"Failed to initialize TTS Service: {str(e)}", exc_info=True)

@app.route('/api/voices', methods=['GET'])
def get_voices():
    """Get available voices from Eleven Labs."""
    if not tts_service:
        return jsonify({"error": "TTS Service not initialized"}), 500

    try:
        voices = tts_service.get_voices()
        if not voices:
            return jsonify({"error": "Failed to fetch voices"}), 500

        # Add AI Agent voice
        ai_agent_voice = {
            'id': '21m00Tcm4TlvDq8ikWAM',
            'name': 'AI Agent',
            'preview_url': '',
            'description': 'AI Assistant voice',
            'language': 'English'
        }
        
        formatted_voices = [{
            'id': voice['voice_id'],
            'name': voice['name'],
            'preview_url': voice.get('preview_url', ''),
            'description': voice.get('description', ''),
            'language': voice.get('labels', {}).get('language', 'English')
        } for voice in voices]
        
        # Add AI Agent to the beginning of the list
        formatted_voices.insert(0, ai_agent_voice)

        logger.info(f"Successfully retrieved {len(voices)} voices")
        return jsonify({"voices": formatted_voices})
    except Exception as e:
        logger.error(f"Error fetching voices: {str(e)}")
        return jsonify({
            "error": "Failed to fetch voices",
            "message": str(e) if app.debug else "Unable to retrieve voice list"
        }), 500

@app.route('/api/library/audio/<filename>')
def get_audio_file(filename):
    try:
        file_path = app.config['STATIC_SOUNDS_DIR'] / secure_filename(filename)
        if not file_path.exists():
            logger.error(f"Audio file not found: {filename}")
            return jsonify({"error": "Audio file not found"}), 404

        return send_file(
            file_path,
            mimetype="audio/mpeg",
            as_attachment=True,
            download_name=filename
        )
    except Exception as e:
        logger.error(f"Error serving audio file {filename}: {str(e)}")
        return jsonify({"error": "Failed to retrieve audio file"}), 500


@app.route('/api/library')
def get_library():
    try:
        files = []
        for file_path in app.config['STATIC_SOUNDS_DIR'].glob('*.mp3'):
            files.append({
                'name': file_path.name,
                'url': url_for('get_audio_file', filename=file_path.name),
                'created': file_path.stat().st_mtime
            })
        return jsonify({"files": sorted(files, key=lambda x: x['created'], reverse=True)})
    except Exception as e:
        logger.error(f"Error getting library: {str(e)}")
        return jsonify({"error": "Failed to retrieve library"}), 500

@app.route('/api/sound-effect', methods=['POST'])
def generate_sound_effect():
    """Generate sound effect from text description."""
    try:
        data = request.get_json()
        if not data or 'description' not in data:
            return jsonify({"error": "No description provided"}), 400

        description = data['description']

        url = "https://api.elevenlabs.io/v1/sound-effects/generate"
        headers = {
            "Accept": "audio/mpeg",
            "Content-Type": "application/json",
            "xi-api-key": os.environ.get('ELEVEN_LABS_API_KEY')
        }

        payload = {
            "text": description
        }

        response = requests.post(url, json=payload, headers=headers)

        if response.status_code == 200:
            return Response(response.content, mimetype='audio/mpeg')
        else:
            return jsonify({"error": f"API Error: {response.text}"}), response.status_code

    except Exception as e:
        logger.error(f"Error generating sound effect: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/text-to-speech', methods=['POST'])
def text_to_speech():
    try:
        data = request.get_json()
        logger.debug(f"Received text-to-speech request: {data}")

        if not data or 'text' not in data:
            logger.error("No text provided in request")
            return jsonify({"error": "Пожалуйста, введите текст"}), 400

        text = data['text']
        if not text.strip():
            logger.error("Empty text provided")
            return jsonify({"error": "Текст не может быть пустым"}), 400

        voice_id = data.get('voice_id')
        if not voice_id:
            logger.error("No voice_id provided")
            return jsonify({"error": "Пожалуйста, выберите голос"}), 400

        if not tts_service:
            logger.error("TTS Service not initialized")
            return jsonify({"error": "Сервис не инициализирован"}), 500

        stability = float(data.get('stability', 0.75))
        similarity_boost = float(data.get('similarity_boost', 0.75))
        style = float(data.get('style', 0.5))

        voice = Voice(
            voice_id=voice_id,
            name="",  # These fields are not needed for the API call
            language="",
            description=""
        )

        mode = VoiceMode(
            name="default",
            stability=stability,
            similarity_boost=similarity_boost,
            style=style,
            description=""
        )

        logger.info(f"Generating speech with voice_id: {voice_id}")
        audio_content = tts_service.text_to_speech(text, voice, mode)

        if not audio_content:
            logger.error("Failed to generate audio content")
            return jsonify({"error": "Не удалось сгенерировать речь"}), 500

        logger.info("Successfully generated speech")
        return Response(audio_content, mimetype='audio/mpeg')

    except Exception as e:
        logger.error(f"Error generating speech: {str(e)}", exc_info=True)
        return jsonify({"error": "Произошла ошибка, повторите попытку"}), 500

def cleanup_old_files():
    """Clean up audio files older than AUDIO_FILE_RETENTION_DAYS days"""
    try:
        current_time = time.time()
        for file_path in app.config['STATIC_SOUNDS_DIR'].glob('*.mp3'):
            if current_time - file_path.stat().st_mtime > app.config['AUDIO_FILE_RETENTION_DAYS'] * 86400:
                file_path.unlink()
                logger.info(f"Deleted old file: {file_path}")
    except Exception as e:
        logger.error(f"Error during file cleanup: {str(e)}")

@app.before_request
def before_request():
    """Middleware to handle pre-request operations"""
    if request.path.startswith('/api/'):
        cleanup_old_files()

@app.errorhandler(Exception)
def handle_error(error):
    """Global error handler"""
    logger.error(f"Unhandled error: {str(error)}", exc_info=True)
    return jsonify({
        "error": "Internal server error",
        "message": str(error) if app.debug else "An unexpected error occurred"
    }), 500

@app.route('/')
def index():
    """Render the main page"""
    return render_template('second_page.html')


if __name__ == "__main__":
    try:
        port = int(os.environ.get("PORT", 5000))
        logger.info(f"Starting Flask server on port {port}")
        app.run(host="0.0.0.0", port=port, debug=True)
    except Exception as e:
        logger.error(f"Failed to start server: {str(e)}", exc_info=True)