import os
import logging
import asyncio
from telegram import Update, WebAppInfo, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, ContextTypes

# Настройка логирования
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Get the domain from environment or use localhost for development
DOMAIN = os.environ.get('REPLIT_URL', '')
if not DOMAIN:
    logger.warning("REPLIT_URL environment variable is not set")
    # Check for alternative environment variables
    REPL_ID = os.environ.get('REPL_ID', '')
    REPL_SLUG = os.environ.get('REPL_SLUG', '')
    REPL_OWNER = os.environ.get('REPL_OWNER', '')

    if REPL_SLUG and REPL_OWNER:
        DOMAIN = f"https://{REPL_SLUG}.{REPL_OWNER}.repl.co"
        logger.info(f"Using constructed domain from REPL_SLUG and REPL_OWNER: {DOMAIN}")
    elif REPL_ID:
        DOMAIN = f"https://{REPL_ID}.id.repl.co"
        logger.info(f"Using constructed domain from REPL_ID: {DOMAIN}")
    else:
        logger.error("No valid domain configuration found")
        DOMAIN = "https://localhost:5000"  # Fallback for development

logger.info(f"Web app domain set to: {DOMAIN}")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send main menu when the command /start is issued."""
    try:
        user_id = update.effective_user.id
        logger.info(f"Start command received from user {user_id}")

        # Log the WebApp URL being used
        webapp_url = f"{DOMAIN}/second_page"  # Using second_page as the main web interface
        logger.info(f"Using WebApp URL for user {user_id}: {webapp_url}")

        keyboard = [
            [InlineKeyboardButton("🎮 Открыть приложение", web_app=WebAppInfo(url=webapp_url))],
            [InlineKeyboardButton("ℹ️ Помощь", callback_data='help')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)

        welcome_message = "Добро пожаловать в Text-to-Speech бот! Нажмите кнопку ниже, чтобы открыть приложение."
        await update.message.reply_text(welcome_message, reply_markup=reply_markup)
        logger.info(f"Welcome message sent to user {user_id}")
    except Exception as e:
        logger.error(f"Error in start command: {e}")
        await update.message.reply_text("Произошла ошибка. Пожалуйста, попробуйте позже.")

async def help_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle help button press."""
    try:
        query = update.callback_query
        if query:
            await query.answer()
            help_text = """
Как использовать бот:
1. Нажмите "Открыть приложение"
2. Введите текст
3. Выберите голос
4. Нажмите "Сгенерировать"

Ваши аудио будут сохранены в библиотеке.
            """
            await query.message.reply_text(help_text)
            logger.info(f"Help message sent to user {update.effective_user.id}")
    except Exception as e:
        logger.error(f"Error in help callback: {e}")
        if update.callback_query:
            await update.callback_query.message.reply_text("Произошла ошибка. Пожалуйста, попробуйте позже.")

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Log Errors caused by Updates."""
    logger.error(f"Update {update} caused error {context.error}")

async def run_bot():
    """Start the bot."""
    try:
        token = os.environ.get('TELEGRAM_BOT_TOKEN')
        if not token:
            logger.error("No token provided!")
            return

        # Create the Application
        application = ApplicationBuilder().token(token).build()

        # Add handlers
        application.add_handler(CommandHandler("start", start))
        application.add_handler(CallbackQueryHandler(help_callback, pattern='^help$'))
        application.add_error_handler(error_handler)

        # Start the bot
        logger.info("Starting bot polling...")
        await application.initialize()
        await application.start()
        await application.run_polling(allowed_updates=Update.ALL_TYPES)

    except Exception as e:
        logger.error(f"Fatal error in bot main: {e}")
        raise