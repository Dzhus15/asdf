import os
import logging
from app import app

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

if __name__ == "__main__":
    try:
        port = int(os.environ.get("PORT", 8082))
        logger.info(f"Starting Flask server on port {port}")

        # Run the Flask app
        app.run(
            host="0.0.0.0",
            port=port,
            debug=True,
            use_reloader=False  # Disable auto-reloader to prevent restart loops
        )
    except Exception as e:
        logger.error(f"Failed to start server: {str(e)}", exc_info=True)