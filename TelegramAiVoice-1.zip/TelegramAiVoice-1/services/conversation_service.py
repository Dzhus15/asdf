import os
import requests
import logging
from typing import Optional

logger = logging.getLogger(__name__)

class ConversationService:
    def __init__(self):
        self.base_url = "https://api.elevenlabs.io/v1"
        self.agent_id = "VK4WJGY6NMpKA0HKLdpn"  # Your public agent ID
        self.headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "xi-api-key": os.environ.get("ELEVENLABS_API_KEY", "")
        }

    def start_conversation(self) -> Optional[str]:
        """Start a new conversation with the ElevenLabs agent."""
        try:
            url = f"{self.base_url}/agents/{self.agent_id}/start"
            response = requests.post(url, headers=self.headers)
            if response.status_code == 200:
                data = response.json()
                return data.get("conversation_id")
            else:
                logger.error(f"Failed to start conversation: {response.text}")
                return None
        except Exception as e:
            logger.error(f"Error starting conversation: {str(e)}")
            return None

    def send_message(self, conversation_id: str, audio_data: bytes) -> Optional[dict]:
        """Send an audio message to the agent and get response."""
        try:
            url = f"{self.base_url}/agents/{self.agent_id}/chat-audio"
            files = {
                'audio': ('message.mp3', audio_data, 'audio/mpeg'),
            }
            params = {
                'conversation_id': conversation_id,
                'language': 'ru'  # Set to Russian for your use case
            }
            response = requests.post(url, headers=self.headers, files=files, params=params)
            
            if response.status_code == 200:
                return {
                    'audio': response.content,
                    'text': response.headers.get('x-transcription', '')
                }
            else:
                logger.error(f"Failed to send message: {response.text}")
                return None
        except Exception as e:
            logger.error(f"Error sending message: {str(e)}")
            return None
