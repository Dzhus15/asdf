import os
import requests
import logging
import time
from typing import Optional, Dict, List
from .voice_service import Voice, VoiceMode, VoiceService

logger = logging.getLogger(__name__)

class TTSService:
    def __init__(self):
        self.api_key = os.environ.get('ELEVEN_LABS_API_KEY')
        if not self.api_key:
            raise ValueError("ELEVEN_LABS_API_KEY not found in environment variables")

        logger.info(f"Initializing TTSService with API key: {self.api_key[:8]}...")

        self.base_url = "https://api.elevenlabs.io/v1"  # Changed to v1
        self.headers = {
            "Accept": "application/json",
            "xi-api-key": self.api_key,
            "Content-Type": "application/json"
        }
        self.voice_service = VoiceService()
        self._voice_cache = {}  # Cache for voice data
        self.request_timeout = 30  # Timeout in seconds
        logger.info("TTSService initialized successfully")

    def get_voices(self) -> List[Dict]:
        """Get available voices from Eleven Labs API."""
        try:
            logger.info("Fetching voices from ElevenLabs API...")
            response = requests.get(
                f"{self.base_url}/voices",
                headers=self.headers,
                timeout=self.request_timeout
            )

            logger.debug(f"API Response status: {response.status_code}")
            if response.status_code == 429:
                logger.error("Rate limit exceeded. Please try again later.")
                return []
            elif response.status_code != 200:
                logger.error(f"API Error: {response.status_code} - {response.text}")
                return []

            response.raise_for_status()
            voices = response.json().get('voices', [])

            # Update voice cache
            for voice in voices:
                voice_id = voice.get('voice_id')
                if voice_id:
                    self._voice_cache[voice_id] = voice

            logger.info(f"Successfully retrieved {len(voices)} voices from ElevenLabs API")
            logger.debug(f"Voices data: {voices}")
            return voices
        except requests.exceptions.RequestException as e:
            logger.error(f"Network error while fetching voices: {str(e)}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error fetching voices: {str(e)}")
            return []

    def text_to_speech(self, text: str, voice: Voice, mode: VoiceMode,
                      optimize_latency: bool = True) -> Optional[bytes]:
        """Convert text to speech using Eleven Labs API."""
        try:
            # Validate and preprocess input text
            if not text or not text.strip():
                logger.error("Empty text provided")
                return None

            # Clean text
            text = text.strip()
            text = ' '.join(text.split())  # Remove extra spaces

            # Validate text length
            if len(text) > 2000:
                logger.error("Text too long (max 2000 characters)")
                return None

            # Check if text contains Cyrillic characters
            is_cyrillic = any(ord(char) > 127 for char in text)

            # For Cyrillic text, always use multilingual model and adjust settings
            if is_cyrillic:
                logger.info("Detected Cyrillic text, using multilingual model with adjusted settings")
                mode.stability = max(0.85, mode.stability)
                mode.similarity_boost = max(0.8, mode.similarity_boost)
                mode.style = min(0.6, mode.style)

            if not self.validate_voice_settings(voice, mode):
                logger.error("Invalid voice settings provided")
                return None

            headers = self.headers.copy()
            headers["Accept"] = "audio/mpeg"

            logger.info(f"Generating speech with voice '{voice.name}' using mode '{mode.name}'")
            logger.debug(f"Text length: {len(text)} chars")
            logger.debug(f"Voice settings - stability: {mode.stability}, "
                        f"similarity_boost: {mode.similarity_boost}, style: {mode.style}")

            model_params = {
                "text": text,
                "model_id": "eleven_multilingual_v2",
                "voice_settings": {
                    "stability": mode.stability,
                    "similarity_boost": mode.similarity_boost,
                    "style": mode.style,
                    "use_speaker_boost": True,
                    "optimize_streaming_latency": optimize_latency
                }
            }

            logger.debug(f"Making request to {self.base_url}/text-to-speech/{voice.voice_id}")
            logger.debug(f"Request payload: {model_params}")

            response = requests.post(
                f"{self.base_url}/text-to-speech/{voice.voice_id}",
                headers=headers,
                json=model_params,
                timeout=self.request_timeout
            )

            logger.debug(f"API Response status: {response.status_code}")
            if response.status_code == 422:
                logger.error("Invalid request parameters or voice settings")
                return None
            elif response.status_code == 429:
                logger.error("Rate limit exceeded. Please try again later.")
                return None
            elif response.status_code != 200:
                logger.error(f"API Error: {response.status_code} - {response.text}")
                return None

            response.raise_for_status()

            content = response.content
            if len(content) < 1024:  # Check if audio is too small
                logger.error("Generated audio is too small, likely an error")
                return None

            logger.info(f"Successfully generated speech for text: {text[:50]}...")
            return content

        except requests.exceptions.RequestException as e:
            logger.error(f"Network error in text-to-speech conversion: {str(e)}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error in text-to-speech conversion: {str(e)}")
            return None

    def validate_voice_settings(self, voice: Voice, mode: VoiceMode) -> bool:
        """Validate voice and mode settings."""
        try:
            if not voice or not voice.voice_id:
                logger.error("Invalid voice: missing voice_id")
                return False

            # Validate and adjust voice settings
            if mode.stability < 0.35:
                logger.warning("Stability too low, adjusting to 0.35")
                mode.stability = 0.35

            if mode.similarity_boost < 0.35:
                logger.warning("Similarity boost too low, adjusting to 0.35")
                mode.similarity_boost = 0.35

            if not mode:
                logger.error("Invalid mode: mode is None")
                return False

            if not (0 <= mode.stability <= 1 and 
                   0 <= mode.similarity_boost <= 1 and 
                   0 <= mode.style <= 1):
                logger.error(f"Invalid mode parameters: stability={mode.stability}, "
                           f"similarity_boost={mode.similarity_boost}, style={mode.style}")
                return False

            return True
        except Exception as e:
            logger.error(f"Error validating voice settings: {str(e)}")
            return False

    def _check_voice_language_support(self, voice: Voice, language: str) -> bool:
        """Check if voice supports specific language."""
        # Always return True since we're using multilingual model
        return True

    def _cleanup_old_audio_files(self, max_age_hours: int = 24):
        """Clean up old generated audio files."""
        try:
            current_time = time.time()
            audio_dir = "static/sounds"
            for file in os.listdir(audio_dir):
                if file.startswith("speech_"):
                    file_path = os.path.join(audio_dir, file)
                    if current_time - os.path.getctime(file_path) > max_age_hours * 3600:
                        os.remove(file_path)
                        logger.info(f"Removed old audio file: {file}")
        except Exception as e:
            logger.error(f"Error cleaning up audio files: {str(e)}")