import logging
from dataclasses import dataclass
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

@dataclass
class Voice:
    name: str
    language: str
    description: str
    voice_id: str

@dataclass
class VoiceMode:
    name: str
    stability: float
    similarity_boost: float
    style: float
    description: str

class VoiceService:
    def __init__(self):
        self.voices = self._init_voices()
        self.voice_modes = self._init_voice_modes()
        logger.info(f"Initialized VoiceService with {len(self.voices)} voices and {len(self.voice_modes)} modes")

    def _init_voices(self) -> Dict[str, Voice]:
        # Updated voice IDs based on ElevenLabs documentation
        return {
            "ai_agent": Voice(
                name="AI Agent",
                language="EN",
                description="AI Assistant voice",
                voice_id="21m00Tcm4TlvDq8ikWAM"
            ),
            "rachel": Voice(
                name="Rachel",
                language="EN",
                description="Calm and clear voice, perfect for narration",
                voice_id="21m00Tcm4TlvDq8ikWAM"
            ),
            "domi": Voice(
                name="Domi",
                language="EN",
                description="Strong and energetic voice",
                voice_id="AZnzlk1XvdvUeBnXmlld"
            ),
            "bella": Voice(
                name="Bella",
                language="EN",
                description="Soft and gentle voice",
                voice_id="EXAVITQu4vr4xnSDxMaL"
            ),
            "antoni": Voice(
                name="Antoni",
                language="EN",
                description="Professional and clear voice",
                voice_id="ErXwobaYiN019PkySvjV"
            ),
            "elli": Voice(
                name="Elli",
                language="EN",
                description="Gentle and warm voice",
                voice_id="MF3mGyEYCl7XYWbV9V6O"
            ),
            "josh": Voice(
                name="Josh",
                language="EN",
                description="Deep and confident voice",
                voice_id="TxGEqnHWrfWFTfGW9XjX"
            ),
            "arnold": Voice(
                name="Arnold",
                language="EN",
                description="Strong and commanding voice",
                voice_id="VR6AewLTigWG4xSOukaG"
            ),
            "adam": Voice(
                name="Adam",
                language="EN",
                description="Clear and professional voice",
                voice_id="pNInz6obpgDQGcFmaJgB"
            ),
            "sam": Voice(
                name="Sam",
                language="EN",
                description="Friendly and conversational voice",
                voice_id="yoZ06aMxZJJ28mfd3POQ"
            ),
            "clyde": Voice(
                name="Clyde",
                language="EN",
                description="Deep and resonant voice",
                voice_id="2EiwWnXFnvU5JabPnv8n"
            )
        }

    def _init_voice_modes(self) -> Dict[str, VoiceMode]:
        return {
            "neutral": VoiceMode(
                name="Нейтральный",
                stability=0.75,
                similarity_boost=0.75,
                style=0.5,
                description="Общий стиль, без специальной окраски."
            ),
            "news": VoiceMode(
                name="Новости",
                stability=0.85,
                similarity_boost=0.8,
                style=0.4,
                description="Строгий, профессиональный стиль."
            ),
            "story": VoiceMode(
                name="История",
                stability=0.6,
                similarity_boost=0.6,
                style=0.7,
                description="Выразительный, повествовательный стиль."
            ),
            "ad": VoiceMode(
                name="Реклама",
                stability=0.5,
                similarity_boost=0.5,
                style=0.9,
                description="Энергичный, убедительный стиль."
            ),
            "education": VoiceMode(
                name="Обучение",
                stability=0.8,
                similarity_boost=0.7,
                style=0.5,
                description="Четкий, спокойный стиль."
            ),
            "expressive": VoiceMode(
                name="Экспрессия",
                stability=0.4,
                similarity_boost=0.4,
                style=0.8,
                description="Креативный, эмоциональный стиль."
            ),
            "documentary": VoiceMode(
                name="Документальный",
                stability=0.85,
                similarity_boost=0.75,
                style=0.45,
                description="Серьезный, информативный стиль."
            ),
            "conversational": VoiceMode(
                name="Разговорный",
                stability=0.65,
                similarity_boost=0.65,
                style=0.6,
                description="Непринужденный, диалоговый стиль."
            ),
            "motivation": VoiceMode(
                name="Мотивация",
                stability=0.55,
                similarity_boost=0.55,
                style=0.85,
                description="Вдохновляющий, энергичный стиль."
            ),
            "fairytale": VoiceMode(
                name="Сказка",
                stability=0.5,
                similarity_boost=0.5,
                style=0.75,
                description="Магический, фантазийный стиль."
            )
        }

    def get_voice(self, voice_name: str) -> Optional[Voice]:
        """Get voice by its name."""
        return self.voices.get(voice_name.lower())

    def get_mode(self, mode_name: str) -> Optional[VoiceMode]:
        """Get voice mode by its name."""
        return self.voice_modes.get(mode_name.lower())

    def get_all_voices(self) -> List[Voice]:
        """Get all available voices."""
        return list(self.voices.values())

    def get_all_modes(self) -> List[VoiceMode]:
        """Get all available voice modes."""
        return list(self.voice_modes.values())

    def get_voice_by_id(self, voice_id: str) -> Optional[Voice]:
        """Get voice by its ElevenLabs ID."""
        for voice in self.voices.values():
            if voice.voice_id == voice_id:
                return voice
        return None