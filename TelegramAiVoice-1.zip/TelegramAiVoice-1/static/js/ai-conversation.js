document.addEventListener('DOMContentLoaded', function() {
    const callButton = document.getElementById('callButton');
    const aiVoiceSelect = document.getElementById('aiVoiceSelect');
    let isProcessing = false;

    // Initialize voice selection
    fetch('/api/voices')
        .then(response => response.json())
        .then(data => {
            data.voices.forEach(voice => {
                const option = document.createElement('option');
                option.value = voice.id;
                option.textContent = voice.name;
                aiVoiceSelect.appendChild(option);
            });
        })
        .catch(error => console.error('Error loading voices:', error));

    // Handle call button click
    callButton.addEventListener('click', async function() {
        if (isProcessing) return;
        
        const selectedVoice = aiVoiceSelect.value;
        if (!selectedVoice) {
            alert('Пожалуйста, выберите голос');
            return;
        }

        try {
            isProcessing = true;
            callButton.textContent = 'ОБРАБОТКА...';
            callButton.disabled = true;

            // For demo, using text input. In next iteration, we'll add voice input
            const userMessage = prompt('Введите ваше сообщение:');
            if (!userMessage) {
                throw new Error('No message provided');
            }

            const response = await fetch('/api/ai-conversation', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    message: userMessage,
                    voice_id: selectedVoice
                })
            });

            const data = await response.json();
            if (response.ok) {
                // Play the audio response
                const audio = new Audio(data.audio_url);
                audio.play();
            } else {
                throw new Error(data.error || 'Failed to process request');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Произошла ошибка: ' + error.message);
        } finally {
            isProcessing = false;
            callButton.textContent = 'ВЫЗОВ';
            callButton.disabled = false;
        }
    });
});
