
let activeCall = null;
let remainingTime = 0;
let timerInterval = null;
let convaiWidget = null;
let selectedDuration = null;

document.addEventListener('DOMContentLoaded', () => {
    const durationButtons = document.querySelectorAll('.duration-btn');
    const timerDisplay = document.getElementById('timer');
    const paymentControls = document.getElementById('payment-controls');
    const payButton = document.getElementById('pay-button');
    const cancelButton = document.getElementById('cancel-button');
    const widgetContainer = document.getElementById('convai-widget-container');
    
    function waitForWidget() {
        convaiWidget = document.querySelector('elevenlabs-convai');
        if (!convaiWidget) {
            setTimeout(waitForWidget, 500);
            return;
        }
        
        convaiWidget.addEventListener('conversationStarted', handleConversationStart);
        convaiWidget.addEventListener('conversationEnded', handleConversationEnd);
    }

    function updateTimer() {
        if (remainingTime <= 0) {
            clearInterval(timerInterval);
            endCall();
            return;
        }
        
        const minutes = Math.floor(remainingTime / 60);
        const seconds = remainingTime % 60;
        timerDisplay.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        remainingTime--;
    }

    function handleConversationStart() {
        if (!activeCall) {
            remainingTime = selectedDuration || 180;
            startTimer();
        }
    }

    function handleConversationEnd() {
        clearInterval(timerInterval);
        timerDisplay.textContent = '';
        activeCall = null;
    }

    function endCall() {
        if (convaiWidget) {
            try {
                convaiWidget.dispatchEvent(new CustomEvent('endConversation'));
                widgetContainer.innerHTML = '';
                widgetContainer.innerHTML = '<elevenlabs-convai agent-id="VK4WJGY6NMpKA0HKLdpn"></elevenlabs-convai>';
                waitForWidget();
            } catch (error) {
                console.error('Error ending call:', error);
            }
        }
        clearInterval(timerInterval);
        timerDisplay.textContent = '';
        activeCall = null;
        widgetContainer.style.display = 'none';
        paymentControls.style.display = 'none';
    }

    function startTimer() {
        if (timerInterval) {
            clearInterval(timerInterval);
        }
        activeCall = {
            startTime: Date.now(),
            duration: remainingTime
        };
        timerInterval = setInterval(updateTimer, 1000);
        updateTimer();
    }

    function resetUI() {
        paymentControls.style.display = 'none';
        widgetContainer.style.display = 'none';
        selectedDuration = null;
    }

    durationButtons.forEach(button => {
        button.addEventListener('click', () => {
            if (activeCall) {
                endCall();
            }
            // Show VPN warning first
            if (window.Telegram && window.Telegram.WebApp) {
                window.Telegram.WebApp.showPopup({
                    title: 'ВНИМАНИЕ!',
                    message: 'Вам нужно включить VPN, без него не сможет работать данная функция',
                    buttons: [{
                        id: 'continue',
                        type: 'ok',
                        text: 'Понятно'
                    }]
                });
            }
            selectedDuration = parseInt(button.dataset.duration);
            paymentControls.style.display = 'flex';
        });
    });

    payButton.addEventListener('click', () => {
        paymentControls.style.display = 'none';
        widgetContainer.style.display = 'block';
        widgetContainer.innerHTML = '<elevenlabs-convai agent-id="VK4WJGY6NMpKA0HKLdpn"></elevenlabs-convai>';
        waitForWidget();
        remainingTime = selectedDuration;
        startTimer();
    });

    durationButtons.forEach(button => {
        button.addEventListener('click', () => {
            if (activeCall) {
                endCall();
            }
            selectedDuration = parseInt(button.dataset.duration);
            
            if (selectedDuration === 30) {
                payButton.textContent = 'Открыть виджет';
                paymentControls.style.display = 'flex';
            } else {
                payButton.textContent = 'Оплатить';
                paymentControls.style.display = 'flex';
            }
        });
    });

    cancelButton.addEventListener('click', () => {
        resetUI();
    });
});
