let mediaRecorder = null;
let audioChunks = [];
let isRecording = false;
let activeConversation = null;

const resourcesToPreload = {
    audio: [
        '/static/demos/aria_demo.mp3',
        '/static/demos/roger_demo.mp3',
        '/static/demos/sarah_demo.mp3',
        '/static/demos/laura_demo.mp3',
        '/static/demos/charly_demo.mp3',
        '/static/demos/charlie_demo.mp3',
        '/static/demos/george_demo.mp3',
        '/static/demos/river_demo.mp3',
        '/static/demos/callum_demo.mp3',
        '/static/sounds/interaction.mp3'
    ],
    images: [
        // Add all images used here
    ]
};

let loadedResources = 0;
const totalResources = resourcesToPreload.audio.length + resourcesToPreload.images.length;


// Create VPN warning popup
function createVpnWarningPopup() {
    const popup = document.createElement('div');
    popup.className = 'vpn-warning-popup';
    popup.innerHTML = `
        <button class="close-button">&times;</button>
        <p>ВНИМАНИЕ! Вам нужно включить VPN, без него не сможет работать данная функция</p>
    `;
    document.body.appendChild(popup);

    popup.querySelector('.close-button').addEventListener('click', () => {
        popup.classList.remove('show');
    });
    
    return popup;
}

document.addEventListener('DOMContentLoaded', async function() {
    // Start with loading state
    document.body.classList.add('loading');
    
    // Create VPN warning popup
    const vpnWarningPopup = createVpnWarningPopup();
    
    // Show popup when AI conversation tab is selected
    document.querySelectorAll('.submenu-button, .menu-button').forEach(button => {
        button.addEventListener('click', function() {
            const tabName = this.getAttribute('data-tab');
            if (tabName === 'ai-conversation') {
                vpnWarningPopup.classList.add('show');
            }
        });
    });

    // Preload all resources
    const audioPromises = resourcesToPreload.audio.map(url => {
        return new Promise((resolve, reject) => {
            const audio = new Audio();
            audio.addEventListener('canplaythrough', () => {
                loadedResources++;
                if (loadedResources === totalResources) {
                    document.body.classList.remove('loading');
                }
                resolve();
            });
            audio.addEventListener('error', reject);
            audio.src = url;
        });
    });

    const imagePromises = resourcesToPreload.images.map(url => {
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = () => {
                loadedResources++;
                if (loadedResources === totalResources) {
                    document.body.classList.remove('loading');
                }
                resolve();
            };
            img.onerror = reject;
            img.src = url;
        });
    });

    Promise.all([...audioPromises, ...imagePromises])
        .then(() => {
            console.log('All resources loaded successfully');
            document.body.classList.remove('loading');
        })
        .catch(error => {
            console.error('Error loading resources:', error);
            document.body.classList.remove('loading');
        });

    // Initialize Telegram WebApp
    let tg = window.Telegram.WebApp;
    tg.expand();

    // Menu functionality
    const menuIcon = document.querySelector('.menu-icon');
    const sidebar = document.querySelector('.sidebar');
    const submenuButtons = document.querySelectorAll('.has-submenu');

    function toggleMenu() {
        sidebar.classList.toggle('active');
        menuIcon.classList.toggle('active');
    }

    function toggleSubmenu(button) {
        const submenu = button.nextElementSibling;
        if (!submenu || !submenu.classList.contains('submenu')) return;

        const isActive = submenu.classList.contains('active');

        // Close all other submenus
        document.querySelectorAll('.submenu').forEach(menu => {
            menu.style.maxHeight = '0px';
            menu.classList.remove('active');
        });
        document.querySelectorAll('.has-submenu').forEach(btn => {
            btn.classList.remove('active');
        });

        if (!isActive) {
            submenu.classList.add('active');
            button.classList.add('active');
            const height = Array.from(submenu.children)
                .reduce((total, child) => total + child.offsetHeight, 0);
            submenu.style.maxHeight = `${Math.min(height + 40, window.innerHeight - 250)}px`;
        }
    }

    // Menu toggle handler
    if (menuIcon) {
        menuIcon.addEventListener('click', function(e) {
            e.preventDefault();
            toggleMenu();
        });
    }

    // Handle submenu toggles
    submenuButtons.forEach(button => {
        button.addEventListener('click', function() {
            toggleSubmenu(this);
        });
    });


    // Update submenu button handling
    document.querySelectorAll('.submenu-button').forEach(button => {
        button.addEventListener('click', function() {
            const tabName = this.getAttribute('data-tab');
            if (tabName) {
                // Hide all tab content
                document.querySelectorAll('.tab-content').forEach(tab => {
                    tab.classList.remove('active');
                });
                // Show selected tab
                const selectedTab = document.getElementById(tabName);
                if (selectedTab) {
                    selectedTab.classList.add('active');
                }

                // Close sidebar on mobile
                if (window.innerWidth <= 768) {
                    sidebar.classList.remove('active');
                    menuIcon.classList.remove('active');
                }
            }
        });
    });

    // Update AI Voice Selection Handler
    const aiVoiceSelect = document.getElementById('aiVoiceSelect');
    const callButton = document.getElementById('callButton');
    const loaderContainer = document.querySelector('.loader-container');

    if (aiVoiceSelect && callButton) {
        aiVoiceSelect.addEventListener('change', function() {
            if (this.value) {
                callButton.style.display = 'block';
                callButton.className = 'call-button generate-button';
            } else {
                callButton.style.display = 'none';
            }
        });

        callButton.addEventListener('click', function() {
            // Disable the call button while processing
            this.disabled = true;

            // Simulate API call (replace with actual API call)
            setTimeout(() => {
                this.disabled = false;
            }, 3000);
        });
    }

    // Tab switching
    document.querySelectorAll('.menu-button').forEach(button => {
        button.addEventListener('click', function() {
            const tabName = this.getAttribute('data-tab');
            if (tabName) {
                document.querySelectorAll('.tab-content').forEach(tab => {
                    tab.classList.remove('active');
                });
                document.getElementById(tabName).classList.add('active');

                // Only close sidebar if it's not a submenu button
                if (!this.classList.contains('has-submenu')) {
                    sidebar.classList.remove('active');
                    menuIcon.classList.remove('active');
                }
            }
        });
    });

    // Voice settings functionality
    const voiceSettingsBtn = document.getElementById('voiceSettingsBtn');
    const voiceSettings = document.getElementById('voiceSettings');
    const confirmModeBtn = document.getElementById('confirmVoiceModeBtn');

    if (voiceSettingsBtn && voiceSettings) {
        voiceSettingsBtn.addEventListener('click', function(e) {
            e.preventDefault();
            voiceSettings.classList.toggle('hidden');

            // Reset temporary selection when opening panel
            if (!voiceSettings.classList.contains('hidden')) {
                tempSelectedMode = currentVoiceMode;
                updateVoiceModeButtons(tempSelectedMode);
            }
        });
    }

    // Add click handlers for voice mode buttons
    document.querySelectorAll('.voice-mode-btn').forEach(button => {
        button.addEventListener('click', function() {
            const mode = this.dataset.mode;
            tempSelectedMode = mode;
            updateVoiceModeButtons(mode);
        });
    });

    // Add handler for confirm button
    if (confirmModeBtn) {
        confirmModeBtn.addEventListener('click', function() {
            if (tempSelectedMode) {
                currentVoiceMode = tempSelectedMode;
                localStorage.setItem('selectedVoiceMode', currentVoiceMode);
                console.log('Applied voice settings:', voiceModeSettings[currentVoiceMode]);
                voiceSettings.classList.add('hidden');
                if (window.Telegram && window.Telegram.WebApp) {
                    window.Telegram.WebApp.showPopup({
                        title: 'Режим голоса изменен',
                        message: `Выбран режим: ${getModeName(currentVoiceMode)}`,
                        buttons: [{type: 'ok'}]
                    });
                }
            }
        });
    }

    // Load saved voice mode if exists
    const savedMode = localStorage.getItem('selectedVoiceMode') || 'neutral';
    currentVoiceMode = savedMode;
    tempSelectedMode = savedMode;
    updateVoiceModeButtons(savedMode);

    // Initialize generate button with sound
    const generateButtonSound = new Audio('/static/sounds/interaction.mp3');
    generateButtonSound.volume = 0.5;
    const generateButton2 = document.getElementById('generateButton');
    if (generateButton2) {
        generateButton2.addEventListener('click', function() {
            generateButtonSound.currentTime = 0;
            generateButtonSound.play().catch(error => console.log('Error playing sound:', error));
            handleGeneration();
        });
    }

    // Initialize user progress if available
    const initData = tg.initData || '';
    if (initData) {
        const user = tg.initDataUnsafe.user;
        if (user && user.id) {
            fetchUserProgress(user.id);
        }
    }

    // Add touch event handlers for smooth scrolling on mobile
    document.querySelectorAll('.submenu').forEach(submenu => {
        let touchStartY;

        submenu.addEventListener('touchstart', (e) => {
            touchStartY = e.touches[0].clientY;
        }, { passive: true });

        submenu.addEventListener('touchmove', (e) => {
            if (!touchStartY) return;

            const touchY = e.touches[0].clientY;
            const scrollTop = submenu.scrollTop;
            const scrollHeight = submenu.scrollHeight;
            const clientHeight = submenu.clientHeight;

            if ((scrollTop <= 0 && touchY > touchStartY) ||
                (scrollTop + clientHeight >= scrollHeight && touchY < touchStartY)) {
                e.preventDefault();
            }
        }, { passive: false });
    });

    // Select default voice mode
    const defaultModeBtn = document.querySelector('.voice-mode-btn[data-mode="neutral"]');
    if (defaultModeBtn) {
        defaultModeBtn.classList.add('active');
    }

    // Add handler for library tab
    const libraryTab = document.querySelector('[data-tab="library"]');
    if (libraryTab) {
        libraryTab.addEventListener('click', function() {
            loadLibraryContent();
        });
    }

    // Start fetching voices - this will initialize custom select after loading
    fetchVoices();

    // Добавляем обработчик для кнопки генерации звукового эффекта
    const generateSoundEffect = document.getElementById('generateSoundEffect');
    const effectInput = document.getElementById('effectInput');

    if (generateSoundEffect && effectInput) {
        generateSoundEffect.addEventListener('click', function() {
            const text = effectInput.value.trim();

            if (!text) {
                if (window.Telegram && window.Telegram.WebApp) {
                    window.Telegram.WebApp.showAlert('Please enter sound effect description');
                }
                return;
            }

            // Проверяем, что текст на английском
            if (!/^[A-Za-z\s\d.,!?-]+$/.test(text)) {
                if (window.Telegram && window.Telegram.WebApp) {
                    window.Telegram.WebApp.showAlert('Please use English characters only');
                }
                return;
            }

            generateButtonSound.currentTime = 0;
            generateButtonSound.play().catch(error => console.log('Error playing sound:', error));

            // Показываем состояние загрузки
            generateSoundEffect.disabled = true;
            generateSoundEffect.textContent = 'Generating...';

            fetch('/api/sound-effect', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    description: text
                })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                if (response.headers.get('content-type').includes('audio')) {
                    return response.blob();
                } else {
                    return response.json().then(data => {
                        throw new Error(data.error || 'Failed to generate sound effect');
                    });
                }
            })
            .then(blob => {
                const url = URL.createObjectURL(blob);
                const audio = new Audio(url);
                audio.play();
            })
            .catch(error => {
                console.error('Error:', error);
                if (window.Telegram && window.Telegram.WebApp) {
                    window.Telegram.WebApp.showAlert('Error generating sound effect. Please try again.');
                }
            })
            .finally(() => {
                generateSoundEffect.disabled = false;
                generateSoundEffect.textContent = 'GENERATE';
            });
        });
    }

    // Initialize conversation UI elements
    const startConversationBtn = document.getElementById('startConversationBtn');
    const recordButton = document.getElementById('recordButton');
    const conversationStatus = document.getElementById('conversationStatus');
    const chatHistory = document.getElementById('chatHistory');


    // Update the startConversationBtn click handler
    if (startConversationBtn) {
        startConversationBtn.addEventListener('click', async function() {
            try {
                const response = await fetch('/api/conversation/start', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({})
                });

                const data = await response.json();
                if (data.status === 'success') {
                    activeConversation = data.conversation_id;
                    if (conversationStatus) {
                        conversationStatus.textContent = 'Conversation started';
                        conversationStatus.classList.add('active');
                    }
                    if (recordButton) {
                        recordButton.disabled = false;
                    }
                } else {
                    throw new Error(data.error || 'Failed to start conversation');
                }
            } catch (error) {
                console.error('Error starting conversation:', error);
                if (window.Telegram && window.Telegram.WebApp) {
                    window.Telegram.WebApp.showAlert('Failed to start conversation. Please try again.');
                }
            }
        });
    }

    // Update the recordButton click handler
    if (recordButton) {
        recordButton.addEventListener('click', async function() {
            if (!activeConversation) {
                if (window.Telegram && window.Telegram.WebApp) {
                    window.Telegram.WebApp.showAlert('Please start a conversation first');
                }
                return;
            }

            if (!isRecording) {
                try {
                    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                    mediaRecorder = new MediaRecorder(stream);
                    audioChunks = [];

                    mediaRecorder.addEventListener("dataavailable", event => {
                        audioChunks.push(event.data);
                    });

                    mediaRecorder.addEventListener("stop", async () => {
                        const audioBlob = new Blob(audioChunks, { type: 'audio/mp3' });
                        await sendAudioToServer(audioBlob);
                        stream.getTracks().forEach(track => track.stop());
                    });

                    mediaRecorder.start();
                    isRecording = true;
                    recordButton.textContent = 'Stop Recording';
                    recordButton.classList.add('recording');
                } catch (error) {
                    console.error('Error accessing microphone:', error);
                    if (window.Telegram && window.Telegram.WebApp) {
                        window.Telegram.WebApp.showAlert('Error accessing microphone. Please check permissions.');
                    }
                }
            } else {
                mediaRecorder.stop();
                isRecording = false;
                recordButton.textContent = 'Start Recording';
                recordButton.classList.remove('recording');
            }
        });
    }
});

function toggleMenu() {
    const sidebar = document.querySelector('.sidebar');
    const menuIcon = document.querySelector('.menu-icon');
    sidebar.classList.toggle('active');
    menuIcon.classList.toggle('active');
}

function toggleSubmenu(button) {
    const submenu = button.nextElementSibling;
    if (!submenu || !submenu.classList.contains('submenu')) return;

    const isActive = submenu.classList.contains('active');

    // Close all other submenus
    document.querySelectorAll('.submenu').forEach(menu => {
        menu.style.maxHeight = '0px';
        menu.classList.remove('active');
    });
    document.querySelectorAll('.has-submenu').forEach(btn => {
        btn.classList.remove('active');
    });

    if (!isActive) {
        submenu.classList.add('active');
        button.classList.add('active');
        const height = Array.from(submenu.children)
            .reduce((total, child) => total + child.offsetHeight, 0);
        submenu.style.maxHeight = `${Math.min(height + 40, window.innerHeight - 250)}px`;
    }
}

function openTab(tabName) {
    const tabs = document.querySelectorAll('.tab-content');
    tabs.forEach(tab => tab.classList.remove('active'));

    const activeTab = document.getElementById(tabName);
    if (activeTab) {
        activeTab.classList.add('active');
    }

    if (tabName !== 'generation') {
        document.querySelector('.sidebar').classList.remove('active');
        document.querySelector('.menu-icon').classList.remove('active');
    }
}

// Обновляем функцию handleGeneration
async function handleGeneration() {
    const textInput = document.getElementById('textInput');
    const voiceSelect = document.getElementById('voiceSelect');
    const generateButton = document.getElementById('generateButton');

    if (!textInput || !textInput.value.trim()) {
        if (window.Telegram && window.Telegram.WebApp) {
            window.Telegram.WebApp.showAlert('Пожалуйста, введите текст для генерации.');
        }
        return;
    }

    if (!voiceSelect || !voiceSelect.value) {
        if (window.Telegram && window.Telegram.WebApp) {
            window.Telegram.WebApp.showAlert('Пожалуйста, выберите голос.');
        }
        return;
    }

    // Get current voice mode settings
    const settings = voiceModeSettings[currentVoiceMode];

    // Show loading state
    const originalText = generateButton.textContent;
    generateButton.textContent = 'Генерация...';
    generateButton.disabled = true;

    try {
        const response = await fetch('/api/text-to-speech', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                text: textInput.value.trim(),
                voice_id: voiceSelect.value,
                stability: settings.stability,
                clarity: settings.similarity_boost,
                emotion: settings.style,
                optimize_latency: true
            })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const filename = `speech_${Date.now()}.mp3`;
        addToRecentGenerations(textInput.value, url, blob, filename);

    } catch (error) {
        console.error('Error:', error);
        if (error.response) {
            error.response.json().then(data => {
                if (window.Telegram && window.Telegram.WebApp) {
                    window.Telegram.WebApp.showAlert(data.error || 'Произошла ошибка при генерации речи. Пожалуйста, попробуйте снова.');
                }
            });
        } else {
            if (window.Telegram && window.Telegram.WebApp) {
                window.Telegram.WebApp.showAlert('Ошибка соединения. Пожалуйста, проверьте подключение к интернету.');
            }
        }
    } finally {
        generateButton.textContent = originalText;
        generateButton.disabled = false;
    }
}

function addToRecentGenerations(text, audioUrl, audioBlob, filename) {
    const generationsList = document.getElementById('generationsList');
    if (!generationsList) return;

    // Store the URL with the filename as key
    audioURLs.set(filename, audioUrl);

    const card = document.createElement('div');
    card.className = 'generation-card';
    card.dataset.filename = filename; // Add filename to card for reference

    const audioElement = new Audio(audioUrl);
    audioElement.controls = false;

    card.innerHTML = `
        <div class="generation-card-content">
            <div class="generation-text">${text.substring(0, 50)}${text.length > 50 ? '...' : ''}</div>
            <div class="generation-info">
                <span class="duration">--:--</span>
                <div class="generation-controls">
                    <button class="play-button" onclick="toggleAudio(this)">▶</button>
                    <button class="download-button" onclick="downloadAudio(this, '${text}', '${filename}')">⬇</button>
                </div>
            </div>
        </div>
    `;

    audioElement.style.display = 'none';
    card.appendChild(audioElement);

    audioElement.addEventListener('loadedmetadata', function() {
        const duration = Math.round(this.duration);
        const minutes = Math.floor(duration / 60);
        const seconds = duration % 60;
        const durationText = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        card.querySelector('.duration').textContent = durationText;
    });

    generationsList.insertBefore(card, generationsList.firstChild);
    saveToLibrary(text, audioBlob, filename);
}

function saveToLibrary(text, audioBlob, filename) {
    const libraryContent = document.querySelector('#library .library-content');
    if (!libraryContent) return;

    const card = document.createElement('div');
    card.className = 'library-card';

    const audioUrl = URL.createObjectURL(audioBlob);
    const audioElement = document.createElement('audio');
    audioElement.src = audioUrl;
    audioElement.controls = true;
    audioElement.style.display = 'none';

    const timestamp = new Date().toLocaleString();

    card.innerHTML = `
        <div class="library-card-content">
            <div class="library-text">${text}</div>
            <div class="library-info">
                <span class="timestamp">${timestamp}</span>
                <span class="duration">--:--</span>
                <div class="library-controls">
                    <button class="play-button" onclick="toggleAudio(this)">▶</button>
                    <button class="download-button" onclick="downloadAudio(this, '${text}', '${filename}')">⬇</button>
                </div>
            </div>
        </div>
    `;

    card.appendChild(audioElement);
    libraryContent.insertBefore(card, libraryContent.firstChild);

    // Update duration once metadata is loaded
    audioElement.addEventListener('loadedmetadata', function() {
        const duration = Math.round(audioElement.duration);
        const minutes = Math.floor(duration / 60);
        const seconds = duration % 60;
        const durationText = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        card.querySelector('.duration').textContent = durationText;
    });
}

function toggleAudio(button) {
    const card = button.closest('.library-card') || button.closest('.generation-card');
    const audio = card.querySelector('audio');

    // Stop all other playing audio elements
    document.querySelectorAll('audio').forEach(otherAudio => {
        if (otherAudio !== audio && !otherAudio.paused) {
            otherAudio.pause();
            otherAudio.closest('.library-card, .generation-card')
                .querySelector('.play-button').textContent = '▶';
        }
    });

    if (audio.paused) {
        audio.play().catch(error => {
            console.error('Error playing audio:', error);
            if (window.Telegram && window.Telegram.WebApp) {
                window.Telegram.WebApp.showAlert('Ошибка воспроизведения аудио');
            }
        });
        button.textContent = '❚❚';
    } else {
        audio.pause();
        button.textContent = '▶';
    }

    audio.onended = () => {
        button.textContent = '▶';
    };
}

function downloadAudio(button, text, filename) {
    try {
        const card = button.closest('.library-card') || button.closest('.generation-card');
        const audio = card.querySelector('audio');

        // Get URL from our Map if it exists, otherwise use audio.src
        const audioUrl = audioURLs.get(filename) || audio.src;

        if (!audioUrl) {
            throw new Error('Audio source not found');
        }

        const downloadLink = document.createElement('a');
        downloadLink.href = audioUrl;
        downloadLink.download = filename || `generated_speech_${Date.now()}.mp3`;

        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);

        if (window.Telegram && window.Telegram.WebApp) {
            window.Telegram.WebApp.showAlert('Аудио файл сохранен');
        }
    } catch (error) {
        console.error('Error downloading audio:', error);
        if (window.Telegram && window.Telegram.WebApp) {
            window.Telegram.WebApp.showAlert('Ошибка при скачивании аудио файла');
        }
    }
}

// Cleanup function to prevent memory leaks
function cleanupAudioURL(filename) {
    const url = audioURLs.get(filename);
    if (url) {
        URL.revokeObjectURL(url);
        audioURLs.delete(filename);
    }
}


function loadLibraryContent() {
    const libraryContent = document.querySelector('#library .library-content');
    if (!libraryContent) return;

    fetch('/api/library')
        .then(response => response.json())
        .then(data => {
            libraryContent.innerHTML = ''; // Clear existing content
            if (data.files && data.files.length > 0) {
                data.files.forEach(file => {
                    const audio = document.createElement('audio');
                    audio.src = file.url;
                    audio.controls = true;
                    audio.style.display = 'none';

                    const card = document.createElement('div');
                    card.className = 'library-card';
                    card.innerHTML = `
                        <div class="library-card-content">
                            <div class="library-text">Аудио от ${new Date(file.created * 1000).toLocaleString()}</div>
                            <div class="library-info">
                                <span class="duration">--:--</span>
                                <div class="library-controls">
                                    <button class="play-button" onclick="toggleAudio(this)">▶</button>
                                    <button class="download-button" onclick="downloadAudio(this, 'audio', '${file.name}')">⬇</button>
                                </div>
                            </div>
                        </div>
                    `;
                    card.appendChild(audio);
                    libraryContent.appendChild(card);

                    // Update duration once metadata is loaded
                    audio.addEventListener('loadedmetadata', function() {
                        const duration = Math.round(audio.duration);
                        const minutes = Math.floor(duration / 60);
                        const seconds = duration % 60;
                        const durationText = `${minutes}:${seconds.toString().padStart(2, '0')}`;
                        card.querySelector('.duration').textContent = durationText;
                    });
                });
            } else {
                libraryContent.innerHTML = '<div class="no-items">Нет сохраненных аудио</div>';
            }
        })
        .catch(error => {
            console.error('Error loading library:', error);
            libraryContent.innerHTML = '<div class="error">Ошибка загрузки библиотеки</div>';
        });
}

function fetchUserProgress(telegramId) {
    fetch(`/api/get_progress/${telegramId}`)
        .then(response => response.json())
        .then(data => {
            if (!data.error) {
                updateProgressUI(data.progress);
            }
        })
        .catch(error => console.error('Error fetching progress:', error));
}

function updateProgressUI(progressData) {
    const progressBar = document.querySelector('.progress');
    if (progressBar && progressData && progressData.length > 0) {
        const latestProgress = progressData[progressData.length - 1];
        progressBar.style.width = `${latestProgress.score}%`;
    }
}

function fetchVoices() {
    const voiceSelect = document.getElementById('voiceSelect');
    if (!voiceSelect) return;

    fetch('/api/voices')
        .then(response => response.json())
        .then(data => {
            if (data.voices) {
                voiceSelect.innerHTML = '';
                data.voices.forEach(voice => {
                    const option = document.createElement('option');
                    option.value = voice.voice_id || voice.id;
                    const displayName = `${voice.name} (${voice.language})`;
                    option.textContent = displayName;
                    voiceSelect.appendChild(option);
                });
                // Initialize custom select after voices are loaded
                initializeVoiceSelect();
            }
        })
        .catch(error => {
            console.error('Error fetching voices:', error);
            if (window.Telegram && window.Telegram.WebApp) {
                window.Telegram.WebApp.showAlert('Ошибка загрузки голосов. Пожалуйста, попробуйте позже.');
            }
        });
}

function updateVoiceModeButtons(selectedMode) {
    document.querySelectorAll('.voice-mode-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.mode === selectedMode) {
            btn.classList.add('active');
        }
    });
}

function getModeName(mode) {
    const modeNames = {
        'neutral': 'Нейтральный',
        'news': 'Новости',
        'story': 'История',
        'advert': 'Реклама',
        'education': 'Обучение',
        'expressive': 'Экспрессия',
        'documentary': 'Документальный',
        'conversational': 'Разговорный',
        'motivational': 'Мотивация',
        'fairytale': 'Сказка'
    };
    return modeNames[mode] || mode;
}

// Add voice demo playback functionality
const voiceDemos = {
    'aria': '/static/demos/aria_demo.mp3',
    'roger': '/static/demos/roger_demo.mp3',
    'sarah': '/static/demos/sarah_demo.mp3',
    'laura': '/static/demos/laura_demo.mp3',
    'charly': '/static/demos/charly_demo.mp3',
    'charlie': '/static/demos/charlie_demo.mp3',
    'george': '/static/demos/george_demo.mp3',
    'river': '/static/demos/river_demo.mp3',
    'callum': '/static/demos/callum_demo.mp3'
};

let currentlyPlaying = null;

function initializeVoiceSelect() {
    const voiceSelect = document.getElementById('voiceSelect');
    if (!voiceSelect) return;

    const customSelect = document.createElement('div');
    customSelect.className = 'custom-voice-select';
    voiceSelect.parentNode.insertBefore(customSelect, voiceSelect);
    voiceSelect.style.display = 'none';

    const selectedVoice = document.createElement('div');
    selectedVoice.className = 'selected-voice';
    selectedVoice.textContent = voiceSelect.options[voiceSelect.selectedIndex]?.text || 'Select Voice';
    customSelect.appendChild(selectedVoice);

    const optionsList = document.createElement('div');
    optionsList.className = 'voice-options';
    customSelect.appendChild(optionsList);

    Array.from(voiceSelect.options).forEach(option => {
        const optionDiv = document.createElement('div');
        optionDiv.className = 'voice-option';

        const nameSpan = document.createElement('span');
        nameSpan.className = 'voice-name';
        nameSpan.textContent = option.text;
        optionDiv.appendChild(nameSpan);

        const playButton = document.createElement('button');
        playButton.className = 'voice-preview-button';
        playButton.innerHTML = '▶';
        playButton.dataset.voice = option.text.toLowerCase().replace(/\s+/g, '_');
        optionDiv.appendChild(playButton);

        // Add demo audio for all supported voices
        const voiceName = option.text.toLowerCase();
        const normalizedVoiceName = voiceName.toLowerCase();
        if (normalizedVoiceName.includes('aria') ||
            normalizedVoiceName.includes('roger') ||
            normalizedVoiceName.includes('sarah') ||
            normalizedVoiceName.includes('laura') ||
            normalizedVoiceName.includes('charly') ||
            normalizedVoiceName.includes('charlie') ||
            normalizedVoiceName.includes('george') ||
            normalizedVoiceName.includes('river') ||
            normalizedVoiceName.includes('callum')) {
            const voiceId = normalizedVoiceName.includes('aria') ? 'aria' :
                                normalizedVoiceName.includes('roger') ? 'roger' :
                                normalizedVoiceName.includes('sarah') ? 'sarah' :
                                normalizedVoiceName.includes('laura') ? 'laura' :
                                normalizedVoiceName.includes('charly') ? 'charly' :
                                normalizedVoiceName.includes('charlie') ? 'charlie' :
                                normalizedVoiceName.includes('george') ? 'george' :
                                normalizedVoiceName.includes('river') ? 'river' :
                                normalizedVoiceName.includes('callum') ? 'callum' : null;
            playButton.onclick = (e) => {
                e.stopPropagation();
                playVoiceDemo(voiceId, playButton);
            };
        }

        optionDiv.onclick = () => {
            voiceSelect.value = option.value;
            selectedVoice.textContent = option.text;
            optionsList.classList.remove('active');
            const event = new Event('change');
            voiceSelect.dispatchEvent(event);
        };

        optionsList.appendChild(optionDiv);
    });

    selectedVoice.onclick = () => {
        optionsList.classList.toggle('active');
    };

    document.addEventListener('click', (e) => {
        if (!customSelect.contains(e.target)) {
            optionsList.classList.remove('active');
        }
    });
}

function playVoiceDemo(voiceId, button) {
    // If there's currently playing audio
    if (currentlyPlaying) {
        // If it's the same voice being clicked
        if (currentlyPlaying.dataset.voiceId === voiceId) {
            currentlyPlaying.audio.pause();
            currentlyPlaying.audio.currentTime = 0;
            if (button) button.innerHTML = '▶';
            currentlyPlaying = null;
            return;
        } else {            // If different voice, stop the current one
            currentlyPlaying.audio.pause();
            currentlyPlaying.audio.currentTime = 0;
            const oldButton = document.querySelector(`.voice-preview-button[data-voice="${currentlyPlaying.dataset.voiceId}"]`);
            if (oldButton) oldButton.innerHTML = '▶';
        }
    }

    const audio = new Audio(voiceDemos[voiceId]);

    // Update button state when audio ends
    audio.addEventListener('ended', function() {
        if (button) button.innerHTML = '▶';
        currentlyPlaying = null;
    });

    // Update button state when audio is paused
    audio.addEventListener('pause', function() {
        if (button) button.innerHTML = '▶';
    });

    // Update button state when audio is playing
    audio.addEventListener('play', function() {
        if (button) button.innerHTML = '⏸';
    });

    audio.play().catch(error => {
        console.error('Error playing demo:', error);
        if (window.Telegram && window.Telegram.WebApp) {
            window.Telegram.WebApp.showAlert('Ошибка воспроизведения демо');
        }
        if (button) button.innerHTML = '▶';
    });

    // Store the currently playing audio and its metadata
    currentlyPlaying = {
        audio: audio,
        dataset: { voiceId: voiceId }
    };
}

// Initialize sound effect only for Generate button
const generateButtonSound = new Audio('/static/sounds/interaction.mp3');
generateButtonSound.volume = 0.5;

// Voice mode parameters mapping with new settings
const voiceModeSettings = {
    'neutral': { stability: 0.75, similarity_boost: 0.75, style: 0.5 },
    'news': { stability: 0.85, similarity_boost: 0.8, style: 0.4 },
    'story': { stability: 0.6, similarity_boost: 0.6, style: 0.7 },
    'advert': { stability: 0.5, similarity_boost: 0.5, style: 0.9 },
    'education': { stability: 0.8, similarity_boost: 0.7, style: 0.5 },
    'expressive': { stability: 0.4, similarity_boost: 0.4, style: 0.8 },
    'documentary': { stability: 0.85, similarity_boost: 0.75, style: 0.45 },
    'conversational': { stability: 0.65, similarity_boost: 0.65, style: 0.6 },
    'motivational': { stability: 0.55, similarity_boost: 0.55, style: 0.85 },
    'fairytale': { stability: 0.5, similarity_boost: 0.5, style: 0.75 }
};

// Current voice mode and temporary selection
let currentVoiceMode = 'neutral';
let tempSelectedMode= null;

// Store audio URLs to prevent garbage collection
const audioURLs = new Map();

// Add this function for sending audio to the server
async function sendAudioToServer(audioBlob) {
    if (!activeConversation) {
        console.error('No active conversation');
        return;
    }

    const formData = new FormData();
    formData.append('audio', audioBlob);

    try {
        const response = await fetch('/api/conversation/message', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        if (data.status === 'success') {
            // Convert base64 audio to blob
            const audioBytes = atob(data.audio_data);
            const arrayBuffer = new ArrayBuffer(audioBytes.length);
            const byteArray = new Uint8Array(arrayBuffer);
            for (let i = 0; i < audioBytes.length; i++) {
                byteArray[i] = audioBytes.charCodeAt(i);
            }
            const audioBlob = new Blob([arrayBuffer], { type: 'audio/mpeg' });
            const audioUrl = URL.createObjectURL(audioBlob);

            // Play the response
            const audio = new Audio(audioUrl);
            audio.play();

            // Update chat history if it exists
            const chatHistory = document.getElementById('chatHistory');
            if (chatHistory) {
                const messageDiv = document.createElement('div');
                messageDiv.className = 'chat-message';
                messageDiv.innerHTML = `
                    <div class="message-content">
                        <div class="message-text">${data.text}</div>
                        <audio controls src="${audioUrl}"></audio>
                    </div>
                `;
                chatHistory.appendChild(messageDiv);
                chatHistory.scrollTop = chatHistory.scrollHeight;
            }
        }
    } catch (error) {
        console.error('Error:', error);
        if (window.Telegram && window.Telegram.WebApp) {
            window.Telegram.WebApp.showAlert('Error processing your message. Please try again.');
        }
    }
}


function updateChatHistory(userText, aiResponse) {
    const chatHistory = document.getElementById('chatHistory');
    if (!chatHistory) return;

    const messageDiv = document.createElement('div');
    messageDiv.className = 'chat-message';
    messageDiv.innerHTML = `
        <div class="user-message">${userText}</div>
        <div class="ai-message">${aiResponse}</div>
    `;
    chatHistory.appendChild(messageDiv);
    chatHistory.scrollTop = chatHistory.scrollHeight;
}

if (recordButton) {
    recordButton.addEventListener('click', async function() {
        if (!activeConversation) {
            if (window.Telegram && window.Telegram.WebApp) {
                window.Telegram.WebApp.showAlert('Please start a conversation first');
            }
            return;
        }

        if (!isRecording) {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                mediaRecorder = new MediaRecorder(stream);
                audioChunks = [];

                mediaRecorder.addEventListener("dataavailable", event => {
                    audioChunks.push(event.data);
                });

                mediaRecorder.addEventListener("stop", async () => {
                    const audioBlob = new Blob(audioChunks, { type: 'audio/mp3' });
                    await sendAudioToServer(audioBlob);
                    stream.getTracks().forEach(track => track.stop());
                });

                mediaRecorder.start();
                isRecording = true;
                recordButton.textContent = 'Stop Recording';
                recordButton.classList.add('recording');
            } catch (error) {
                console.error('Error accessing microphone:', error);
                if (window.Telegram && window.Telegram.WebApp) {
                    window.Telegram.WebApp.showAlert('Error accessing microphone. Please check permissions.');
                }
            }
        } else {
            mediaRecorder.stop();
            isRecording = false;
            recordButton.textContent = 'Start Recording';
            recordButton.classList.remove('recording');
        }
    });
}