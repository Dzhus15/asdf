// Список ресурсов для предзагрузки
const resourcesToPreload = {
    audio: [
        '/static/demos/aria_demo.mp3',
        '/static/demos/roger_demo.mp3',
        '/static/demos/sarah_demo.mp3',
        '/static/demos/laura_demo.mp3',
        '/static/demos/charly_demo.mp3',
        '/static/demos/charlie_demo.mp3',
        '/static/demos/george_demo.mp3',
        '/static/demos/river_demo.mp3',
        '/static/demos/callum_demo.mp3',
        '/static/sounds/interaction.mp3'
    ],
    images: [
        'https://drive.google.com/thumbnail?id=1WCdqGlJNcZVKgGg2JG_cke1yOI1K3CpY&sz=w2000',
        'https://drive.google.com/thumbnail?id=1np2fNEMsUl0LzuQjrNX9U-lCQONdZwLO&sz=w1000'
    ]
};

let loadedResources = 0;
const totalResources = resourcesToPreload.audio.length + resourcesToPreload.images.length;

function preloadAudio(url) {
    return new Promise((resolve, reject) => {
        const audio = new Audio();
        audio.addEventListener('canplaythrough', () => {
            loadedResources++;
            resolve();
        });
        audio.addEventListener('error', reject);
        audio.src = url;
    });
}

function preloadImage(url) {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => {
            loadedResources++;
            resolve();
        };
        img.onerror = reject;
        img.src = url;
    });
}

function startPreloading() {
    console.log('Starting preload sequence...');
    document.body.classList.add('loading');
    
    const audioPromises = resourcesToPreload.audio.map(url => preloadAudio(url));
    const imagePromises = resourcesToPreload.images.map(url => preloadImage(url));

    Promise.all([...audioPromises, ...imagePromises])
        .then(() => {
            console.log('All resources loaded successfully');
            document.body.classList.remove('loading');
            // Delay redirect slightly to show completion
            setTimeout(() => {
                window.location.href = '/second_page';
            }, 500);
        })
        .catch(error => {
            console.error('Error preloading resources:', error);
            document.body.classList.remove('loading');
            alert('Произошла ошибка при загрузке ресурсов');
        });
}

// Модифицируем функцию toggleRotation для запуска предзагрузки
function toggleRotationAndPreload() {
    const toggle = document.getElementById('toggle');
    if (toggle.checked) {
        startPreloading();
    }
}