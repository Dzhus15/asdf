
import requests
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_eleven_labs_api(api_key):
    headers = {
        "Accept": "application/json",
        "xi-api-key": api_key
    }
    
    try:
        response = requests.get(
            "https://api.elevenlabs.io/v1/voices",
            headers=headers,
            timeout=10
        )
        
        if response.status_code == 200:
            logger.info("API Key is valid! Successfully connected to ElevenLabs API")
            return True
        elif response.status_code == 401:
            logger.error("Invalid API key")
            return False
        else:
            logger.error(f"API error: {response.status_code} - {response.text}")
            return False
    except Exception as e:
        logger.error(f"Connection error: {str(e)}")
        return False

if __name__ == "__main__":
    api_key = "sk_d6b14d16be7713fb5f084bd28c11219fc2d681254c641f5e"
    test_eleven_labs_api(api_key)
